// ==UserScript==
// @name         YouTube AutoPlay - Channel
// @version      1.0.0
// @description  This script Autoplay Youtube
// @author       bjemtj
// @match        *music.youtube.com/channel*
// @run-at       document-end
// @updateURL    https://bjemtj.github.io/tampermonkey/youtube-channel.js
// @downloadURL  https://bjemtj.github.io/tampermonkey/youtube-channel.js
// @grant        none
// ==/UserScript==
