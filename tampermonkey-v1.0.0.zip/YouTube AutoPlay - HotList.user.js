// ==UserScript==
// @name         YouTube AutoPlay - HotList
// @version      1.0.0
// @description  This script Autoplay Youtube
// @author       bjemtj
// @match        *music.youtube.com/hotlist*
// @run-at       document-end
// @updateURL    https://bjemtj.github.io/tampermonkey/youtube-hotlist.js
// @downloadURL  https://bjemtj.github.io/tampermonkey/youtube-hotlist.js
// @grant        none
// ==/UserScript==