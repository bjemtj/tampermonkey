// ==UserScript==
// @name         Tidal AutoPlay - MANAGER
// @version      1.0.0
// @description  This script Autoplay Tidal
// @author       bjemtj
// @match        *listen.tidal.com/*
// @run-at       document-end
// @updateURL    https://bjemtj.github.io/tampermonkey/tidal-main.js
// @downloadURL  https://bjemtj.github.io/tampermonkey/tidal-main.js
// @grant        none
// ==/UserScript==